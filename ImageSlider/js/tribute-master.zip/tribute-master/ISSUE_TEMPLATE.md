**How can we reproduce this bug?**

1. Step one
2. Step two
3. Step three

**What did you expect to happen?**

**What happened instead?**

**Link (jsfiddle/plunkr/codepen) or Screenshot:**
You can fork this Codepen as a base for reproducing your issue: 
https://codepen.io/mrsweaters/pen/OxxdWv?editors=1010#0
