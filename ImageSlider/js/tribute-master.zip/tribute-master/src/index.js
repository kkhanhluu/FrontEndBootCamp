/**
* Tribute.js
* Native ES6 JavaScript @mention Plugin
**/

import Tribute from "./Tribute";

export default Tribute;
